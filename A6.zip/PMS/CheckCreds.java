import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class CheckCreds extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

            
            String user = request.getParameter("user");
            String pass = request.getParameter("pass");
            

            response.setContentType("text/html");
            PrintWriter pw = response.getWriter();

            // pw.println("<B>The selected username is: ");
            // pw.println(user);
            // pw.println("<B>The selected password is: ");
            // pw.println(pass);

            if(user.equals("admin") && pass.equals("ramen")){
                RequestDispatcher rd = request.getRequestDispatcher("app.html");
                rd.forward(request,response);
            }

            else{
                pw.println("<h1>Wrong username or password</h1>");
                RequestDispatcher rd = request.getRequestDispatcher("index.html");
                rd.include(request,response);
            }

            pw.close();
    }
}