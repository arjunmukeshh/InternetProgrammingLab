function validateForm() {
    // Salutations

    var salutations = document.getElementsByName("salutation");
    var salutationSelected = false;
    for (var i = 0; i < salutations.length; i++) {
        if (salutations[i].checked) {
            salutationSelected = true;
        }
    }
    console.log(salutationSelected)
    if (!salutationSelected) {
        alert("Please select your salutation.");
        return false;
    }

    // Participant Name
    var participantName = document.getElementById("participantName");
    if (participantName.value == "") {
        alert("Please enter your name.");
        participantName.focus();
        return false;
    }

    // Username
    var username = document.getElementById("username");
    var usernameRegex = /^[A-Za-z]+$/;
    if (!usernameRegex.test(username.value)) {
        alert("Username should contain only alphabets.");
        username.focus();
        return false;
    }

    // Password
    var password = document.getElementById("password");
    var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W).{8,}$/;
    if (!passwordRegex.test(password.value)) {
        alert("Password should contain at least one uppercase letter, one lowercase letter, one special character, one number, and should be minimum 8 characters long.");
        password.focus();
        return false;
    }

    // Email
    var email = document.getElementById("email");
    var emailRegex = /^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$/;
    if (!emailRegex.test(email.value)) {
        alert("Please enter a valid email address.");
        email.focus();
        return false;
    }

    // Date of Birth
    var dob = document.getElementById("dob");
    var today = new Date();
    var dobDate = new Date(dob.value);
    var age = today.getFullYear() - dobDate.getFullYear();
    if (age < 18 || age > 35) {
        alert("Your age should be between 18 and 35 years.");
        dob.focus();
        return false;
    }

    // Languages known
    var languages = document.getElementsByName("language");
    var languageSelected = false;
    for (var i = 0; i < languages.length; i++) {
        if (languages[i].checked) {
            languageSelected = true;
            if (languages[i].value == "others") {
                var otherLanguageInput = document.getElementById("otherLanguageInput");
                if (otherLanguageInput.value == "") {
                    alert("Please enter the other language you know.");
                    otherLanguageInput.focus();
                    return false;
                }
            }
        }
    }
    if (!languageSelected) {
        alert("Please select at least two languages you know.");
        return false;
    }

    alert("Details have been submitted successfully.");
    return true;
}

function clearForm() {
    document.getElementById("registrationForm").reset();
    document.getElementById("participantName").focus();
}