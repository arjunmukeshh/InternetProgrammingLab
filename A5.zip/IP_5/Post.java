import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
public class Post extends HttpServlet {
    public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String sal = request.getParameter("gender");
        String name = request.getParameter("name");
        String uname = request.getParameter("uname");
        String pwd = request.getParameter("pwd");
        String mail = request.getParameter("em");
        String dob = request.getParameter("dob");
        String photo = request.getParameter("photo");
        String[] check = request.getParameterValues("l1");
        String txt = request.getParameter("comment");

        response.setContentType("text/html");
        PrintWriter pw = response.getWriter();

        pw.println("<table border=1>");

        pw.println("<tr><th>Salutation</th> <td>"+sal+"</td></tr>");
        pw.println("<tr><th>Name</th> <td>"+name+"</td></tr>");
        pw.println("<tr><th>Username</th> <td>"+uname+"</td></tr>");
        pw.println("<tr><th>Password</th> <td>"+pwd+"</td></tr>");
        pw.println("<tr><th>Email</th> <td>"+mail+"</td></tr>");
        pw.println("<tr><th>DOB</th> <td>"+dob+"</td></tr>");
        pw.println("<tr><th>Photo</th> <td>"+photo+"</td></tr>");
        pw.println("<tr><th>Expertise</th> <td>"+txt+"</td></tr>");
        pw.println("<tr><th>Languages</th> <td>");
        for (int i = 0 ; i < check.length;i++) pw.println(check[i]);
        pw.println("</td></tr>");

        pw.println("<tr><th>Expertise</th> <td>"+txt+"</td></tr>");

        pw.println("</table");

        pw.close();
}
}