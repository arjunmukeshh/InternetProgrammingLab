function checkGender(){ 
    var salutation=document.querySelector('input[name="gender"]:checked');
    if(salutation==null)
    {
        document.getElementById("error_gender").innerHTML="* Please choose a salutation"; 
        return false;
    }
    else{
        document.getElementById("error_gender").innerHTML=""; 
        return true;
    }
}

function checkLanguage(){ 
    var lang=document.querySelectorAll('input[name="others"]:checked');
    
    // if(salutation==null)
    // {
    //     document.getElementById("error_gender").innerHTML="* Please choose a salutation"; 
    //     return false;
    // }
    // else{
    //     document.getElementById("error_gender").innerHTML=""; 
    //     return true;

    // }
    console.log(lang)
    if(lang){
       
        document.getElementById("textareabox").style.display="block";         
        //document.getElementById("error_language").innerHTML="";
    }
}

function checkName(){
    var name=document.getElementById("name").value;
    if(name.length>0){ 
        var pattern=/^([A-Za-z]\s){1,}([A-Za-z]+\s)([A-Za-z]+)$/
        if(!name.match(pattern)){
            document.getElementById("error_name").innerHTML='* Initial FName LName. Invalid name!';
            document.getElementById("name").focus();
            return false;
        }
        else{
            document.getElementById("error_name").innerHTML="";
            // document.getElementById("username").focus();
            return true;
        }
    }
    else{
        document.getElementById("error_name").innerHTML="* Name can't be empty!";
        document.getElementById("name").focus();
        return false;
    }
}
function checkUsername(){
    var username=document.getElementById("username").value;
    if(username.length>0){ 
        var pattern=/^[A-Za-z]+$/;
        if(!username.match(pattern)){
            document.getElementById("error_username").innerHTML='* Invalid username! Use only alphabets!';
            document.getElementById("username").focus();
            return false;
        }
        else{
            document.getElementById("error_username").innerHTML="";
            return true;
        }
    }
    else{
        document.getElementById("error_username").innerHTML="* Username can't be empty!";
        document.getElementById("username").focus();
        return false;
    }
}

function checkPwd(){
    var pwd=document.getElementById("password").value;
    if(pwd.length>0){
        if(pwd.length<8){
            document.getElementById("error_pwd").innerHTML="* Minimum length of the password id 8!";
            document.getElementById("password").focus();
            return false;
        }
        if(pwd.search(/[A-Z]/)==-1){
            document.getElementById("error_pwd").innerHTML=('* Inavalid - No uppercase letter!');
            document.getElementById("password").focus();
            return false;
        }
        if(pwd.search(/[a-z]/)==-1){
            document.getElementById("error_pwd").innerHTML='* Inavalid - No lowercase letter!';
            document.getElementById("password").focus();
            return false;
        }
        if(pwd.search(/[0-9]/)==-1){
            document.getElementById("error_pwd").innerHTML='* Inavalid - No number!';
            document.getElementById("password").focus();
            return false;
        }
        if(pwd.search(/[^a-zA-Z0-9]/)==-1){
            document.getElementById("error_pwd").innerHTML='* Inavalid - No special character!';
            document.getElementById("password").focus();
            return false;
        }
        document.getElementById("error_pwd").innerHTML="";
        return true;
    }
    else{
        document.getElementById("error_pwd").innerHTML="* Password can't be empty!";
        document.getElementById("password").focus();
        return false; 
    }
}

function checkMail(){
    var mail=document.getElementById("mail").value;
    if(mail.length>0){
        var pattern=/^[A-Za-z_0-9\.]+@([a-zA-Z0-9]+\.)+[a-z]{2,}$/
        if(!mail.match(pattern)){
            document.getElementById("error_mail").innerHTML='* Please enter valid mail id! Pattern-xxxx@some.com,xxx@some1.some2.net. ';
            document.getElementById("mail").focus();
            return false;
        }
        document.getElementById("error_mail").innerHTML='';
        return true;
    }
    else{
        document.getElementById("error_mail").innerHTML='* Email cant be empty!';
        document.getElementById("mail").focus();
        return false;
    }
}
// function checkPhn(){
//     var phn=document.getElementById("phone").value;
//     if(phn.length!=10){

//     }
//     else{
//         document.getElementById("error_phone").innerHTML=""
//     }
// }

function checkdob(){
    var dob=document.getElementById("dob").value;
    var today=new Date();
    
    if(dob){
        var age=today.getYear()-dob.getYear();
        document.getElementById("error_dob").innerHTML=age;
    }
}

function checkDate(){
    let dateformat = /^(0?[1-9]|[1-2][0-9]|3[01])[\/](0?[1-9]|1[0-2])/;
    date=document.getElementById("dob").value;
    // Matching the date through regular expression      
    if (date.match(dateformat)) {
        let operator = date.split('/');

        // Extract the string into month, date and year      
        let datepart = [];
        if (operator.length > 1) {
            datepart = date.split('/');
        }
        let day = parseInt(datepart[0]);
        let month = parseInt(datepart[1]);
        let year = parseInt(datepart[2]);

        // Create a list of days of a month      
        // let ListofDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
        // if (month == 1 || month > 2) {
        //     if (day > ListofDays[month - 1]) {
        //         //to check if the date is out of range
        //         document.getElementById("error_dob").innerHTML="Invalid Month";     
        //         return false;
        //     }
        // } else if (month == 2) {
        //     let leapYear = false;
        //     if ((!(year % 4) && year % 100) || !(year % 400)) leapYear = true;
        //     if ((leapYear == false) && (day >= 29)) {
        //         document.getElementById("error_dob").innerHTML="Invalid date(leap year)";
        //         return false;
        //     }
        //     else
        //         if ((leapYear == true) && (day > 29)) {
        //             document.getElementById("error_dob").innerHTML="Invalid Day";
        //             return false;
        //         }
        // }
        var today=new Date();
        var test=today.getFullYear()-year
        
        var choice=(today.getFullYear()-year>18 && today.getFullYear()-year<35)
        document.getElementById("error_dob").innerHTML=choice;
        if (choice){
            document.getElementById("error_dob").innerHTML="";
        }
        else{
            document.getElementById("error_dob").innerHTML="Age should be between 18 and 35";
        }
    } else {
        document.getElementById("error_dob").innerHTML="Date form DD/MM/YYYY";
        return false;
    }
    return "Valid date";
}

function onClear(){
    var getValue= document.getElementById("name");
        if (getValue.value !="") {
            getValue.value = "";
        }
    getValue= document.getElementById("username");
        if (getValue.value !="") {
            getValue.value = "";
        }
    getValue= document.getElementById("mail");
        if (getValue.value !="") {
            getValue.value = "";
        }
    getValue= document.getElementById("password");
        if (getValue.value !="") {
            getValue.value = "";
        }
    getValue= document.getElementById("dob");
        if (getValue.value !="") {
            getValue.value = "";
        }
    getValue= document.getElementById("textareabox");
        if (getValue.value !="") {
            getValue.value = "";
        }
    var ele = document.querySelectorAll("input[type=gender]");
        for(var i=0;i<ele.length;i++){
           ele[i].checked = false;
        }
    var ele = document.querySelectorAll("input[type=radio]");
        for(var i=0;i<ele.length;i++){
           ele[i].checked = false;
        }
    var ele = document.querySelectorAll("input[type=checkbox]");
        for(var i=0;i<ele.length;i++){
           ele[i].checked = false;
        }
    document.getElementById("name").focus();
    
}
function onRegister(){
    window.alert("Details Have been submitted Succesfully")
}

function helpName(){
    document.getElementById("error_name").innerHTML="* Initial FName LName"
}
function helpUname(){
    document.getElementById("error_username").innerHTML="* Only Alphabets"
}

function helpEmail(){
    document.getElementById("error_mail").innerHTML="* Pattern -xxxx@some.com,xxx@some1.some2.net"
}

function helpPwd(){
    document.getElementById("error_mail").innerHTML="* atleast one letter uppercase and one lowercase letter, one special character, one number and minimum 8 character length mandatory"
}

name=document.getElementById("name").focus()