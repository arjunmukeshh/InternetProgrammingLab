import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class Validate extends HttpServlet {
		// JDBC driver name and database URL
        static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
        static final String DB_URL="jdbc:mysql://localhost:3306/test";
  
        //  Database credentials
        static final String USER = "root";
        static final String PASS = "ssn@123";

        public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {
        response.setContentType("text/html");
		PrintWriter out = response.getWriter();
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String correct_password = "";
        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);
            //Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);

            // Execute SQL query
            Statement stmt = conn.createStatement();
            String ID = request.getParameter("Patient_ID");
            String sql = "SELECT * FROM user WHERE username = '" + username + "'";
            ResultSet rs = stmt.executeQuery(sql);

            if(rs.next())
            {
                correct_password = rs.getString("password");
            }

            // Clean-up environment
            rs.close();
            stmt.close();
            conn.close();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        if(((String)password).equalsIgnoreCase((String)correct_password))
        {
		
			// Getting RequestDispatcher object
            // for collaborating with Welcome servlet
            HttpSession session = request.getSession();
            session.setAttribute("username", username);

            RequestDispatcher rd = request.getRequestDispatcher("Login");
			// forwarding the request to Welcome.java
            rd.forward(request, response);
        }
		else
		{
            RequestDispatcher rd = request.getRequestDispatcher("/index.html");
        
			rd.forward(request, response); 
		}
    }
}
