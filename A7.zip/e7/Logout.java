import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Logout extends HttpServlet {
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        session.invalidate();
        
        out.println("<html><head><title>Logout</title>" + 
			"<meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
			"<link rel='preconnect' href='https://fonts.googleapis.com'>" +
			"<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>" +
			"<link href='https://fonts.googleapis.com/css2?family=Tomorrow&display=swap' rel='stylesheet'>" +
			"<link rel='stylesheet' href='style.css'>" + "</head><body>");

        out.println("<br><h1 align='center' style='font-size: 3em; text-align: center;'>Successfully Invalidated!</h1>");

        out.println("<form action='index.html'>" +
        "<input type='submit' value='Login' style='position:absolute; top:30vh; left: 90vh;'></form>" + 
        "</body></html>");
    }
}