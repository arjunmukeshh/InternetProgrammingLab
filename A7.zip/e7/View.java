import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class View extends HttpServlet {
    // JDBC driver name and database URL
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
    static final String DB_URL="jdbc:mysql://localhost:3306/test";

    //  Database credentials
    static final String USER = "root";
    static final String PASS = "ssn@123";

    public void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        String user = (String)session.getAttribute("username");
        try {
            // Register JDBC driver
            Class.forName(JDBC_DRIVER);
            //Class.forName("com.mysql.cj.jdbc.Driver");

            // Open a connection
            Connection conn = DriverManager.getConnection(DB_URL, USER, PASS);
            
            // Execute SQL query
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM user_details WHERE firstname = '" + user + "'";
            ResultSet rs = stmt.executeQuery(sql);

            out.println("<html><head><title>View Profile</title>" + 
            "<meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
            "<link rel='preconnect' href='https://fonts.googleapis.com'>" +
            "<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>" +
            "<link href='https://fonts.googleapis.com/css2?family=Tomorrow&display=swap' rel='stylesheet'>" +
            "<link rel='stylesheet' href='style.css'>" + "</head><body style=\"background-color:blue\">"); 
            
            out.println("<br><h1 align = \"center\" style=\"font-size: 3em; text-align: center;\">Welcome " + user + " to the profile page!</h1>");
            //Retrieve by column name
            if(rs.next())
            {
                String id  = rs.getString("id");
                String firstname = rs.getString("firstname");
                String lastname = rs.getString("lastname");
                String dob = rs.getString("dob");
                int age = rs.getInt("age");
                String address = rs.getString("address");
                String gender = rs.getString("gender");
                String phno = rs.getString("phno");

                out.println("<br><br><table align=\"center\"><tr><th>ID</th><th>First Name</th><th>Last Name</th><th>Date of Birth</th><th>Age</th><th>Address</th><th>Gender</th><th>Phone Number</th></tr><tr>" +
                "<td style=\"padding:2em;\">" + id + "</td>" +
                "<td style=\"padding:2em;\">" + firstname + "</td>" +
                "<td style=\"padding:2em;\">" + lastname + "</td>" +
                "<td style=\"padding:2em;\">" + dob + "</td>" + 
                "<td style=\"padding:2em;\">" + age + "</td>" +
                "<td style=\"padding:2em;\">" + address + "</td>" + 
                "<td style=\"padding:2em;\">" + gender + "</td>" + 
                "<td style=\"padding:2em;\">" + phno + "</td></tr>");    
            }

            out.println("<form action='http://localhost:8080/e7/Logout' method='get'><input type='submit' value='Logout' style='position:absolute; top:60vh; left: 90vh;'></form>");
            out.println("</body></html>"); 

            // Clean-up environment
            rs.close();
            stmt.close();
            conn.close();
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}