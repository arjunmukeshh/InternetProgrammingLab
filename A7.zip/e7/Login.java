import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Login extends HttpServlet {
 
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        HttpSession session = request.getSession();
        String user = (String)session.getAttribute("username");
        
        out.println("<html><head><title>Login</title>" + 
			"<meta name='viewport' content='width=device-width, initial-scale=1.0'>" +
			"<link rel='preconnect' href='https://fonts.googleapis.com'>" +
			"<link rel='preconnect' href='https://fonts.gstatic.com' crossorigin>" +
			"<link href='https://fonts.googleapis.com/css2?family=Tomorrow&display=swap' rel='stylesheet'>" +
			"<link rel='stylesheet' href='style.css'>" + "</head><body style=\"background-color:blue\">");

        out.println("<br><h1 align='center' style='font-size: 3em; text-align: center;'>Welcome " + user + "!</h1>");

        out.println("<form action='http://localhost:8080/e7/View' method='get'>" +
        "<input type='submit' value='View' style='position:absolute; top:30vh; left: 65vh;'></form>" + 
        "<form action='http://localhost:8080/e7/Logout' method='get'>" +
        "<input type='submit' value='Logout' style='position:absolute; top:30vh; left: 115vh;'></form>" + 
        "</body></html>");
    }
}
