const Footer = () => {
  return (
    <footer className="footer">All rights reserved (c)</footer>
  );
}

export default Footer;

