import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/CountryNamesServlet")
public class CountryNamesServlet extends HttpServlet {
   public void doGet(HttpServletRequest request, HttpServletResponse response)
      throws ServletException, IOException {
      
      // Retrieve the query string from the AJAX request
      String query = request.getParameter("query");

      // Create a connection to the MySQL database
      String jdbcUrl = "jdbc:mysql://localhost:3306/test";
      String username = "root";
      String password = "ssn@123";
      try (Connection connection = DriverManager.getConnection(jdbcUrl, username, password)) {
         // Query the database to retrieve country names that match the partial text entered by the user
         String sql = "SELECT name FROM countries WHERE name LIKE ? ORDER BY name ASC";
         PreparedStatement statement = connection.prepareStatement(sql);
         statement.setString(1, query + "%");
         ResultSet result = statement.executeQuery();

         // Create a JSON object containing the matched country names
         StringBuilder json = new StringBuilder();
         json.append("[");
         boolean first = true;
         while (result.next()) {
            if (!first) {
               json.append(",");
            }
            json.append("\"");
            json.append(result.getString("name"));
            json.append("\"");
            first = false;
         }
         json.append("]");

         // Set the response content type to JSON and write the JSON object to the response
         response.setContentType("application/json");
         response.setCharacterEncoding("UTF-8");
         response.getWriter().write(json.toString());
      } catch (SQLException ex) {
         // Handle database errors
         throw new ServletException("Database error", ex);
      }
   }
}
